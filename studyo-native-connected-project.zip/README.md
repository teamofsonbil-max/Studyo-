# Studyo Native Android — connected starter

This is a **native Android app** (Kotlin Android Views; no WebView) based on the supplied Studyo ZIP's Firebase/Cloudinary configuration.

## Included
- Firebase email/password sign-in and account creation
- Firestore real-time people, posts, follows, likes and comments
- Native Explore and profile editing
- Native direct messages using the existing `dm` collection shape
- Cloudinary unsigned upload for images, videos and PDFs; PDFs appear in Notes
- GitHub Actions workflow to build a debug APK

## Important before building/testing
1. The supplied web project config points to Firebase project `samosa-gang` (not `safe-x-32b69`). This project intentionally uses the configuration found in your uploaded ZIP. It does not change SafeX.
2. In Firebase Console for `samosa-gang`, enable **Authentication → Email/Password** and create/enable **Firestore Database**. If these are not enabled, login or data will fail.
3. Ensure Firestore Security Rules allow authenticated users only and validate ownership. Do not use open public write rules. See `firebase-rules.example.txt` for a starting point to review and adapt.
4. Cloudinary upload uses the existing cloud name `gpvkcufd` and unsigned preset `studyo_unsigned` from your website. If that preset is disabled/missing, media upload fails; create/verify an unsigned upload preset in Cloudinary. Never put a Cloudinary API secret in the app.
5. Existing web ZIP did not include Firestore rules or prove that the Cloudinary preset is currently active. Those services cannot be verified from source alone.
6. This project uses the existing collection names and field shapes where visible in the supplied website: `people`, `posts`, `follows`, `stories`, and `dm`. Stories creation/viewer and push notifications are not yet included in this native starter. Real-time stories UI, image avatars, unread notifications, password reset, Google login, and release signing still need additional implementation.
7. The app is not built/tested in this environment. Use GitHub Actions to compile and inspect logs; do not publish to Play Store until thoroughly tested.

## Build on Android phone only
1. Extract this ZIP on your phone.
2. Create a GitHub repository, e.g. `studyo-native-connected`.
3. Upload all extracted contents to the repository root, including `.github/workflows/build-apk.yml`.
4. Open **Actions → Build Studyo Native APK → Run workflow** (or push files to `main`).
5. When the run succeeds, open it and download artifact `studyo-native-debug-apk`.
6. Extract the artifact ZIP and install `app-debug.apk` on your Android phone.

The APK is a debug build for testing, not a Play Store signed release.
