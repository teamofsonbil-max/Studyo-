plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.studyo.nativeapp"
    compileSdk = 35
    defaultConfig { applicationId = "com.studyo.nativeapp"; minSdk = 23; targetSdk = 35; versionCode = 2; versionName = "1.1" }
}
dependencies {
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
    implementation("androidx.core:core-ktx:1.15.0")
}
